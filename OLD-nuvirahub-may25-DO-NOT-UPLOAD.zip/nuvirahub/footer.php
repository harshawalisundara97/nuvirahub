<?php
/**
 * Footer template.
 *
 * @package Nuvirahub
 */

$nv_about     = nuvirahub_get_page_by_title( 'About' );
$nv_services  = nuvirahub_get_page_by_title( 'Services' );
$nv_portfolio = nuvirahub_get_page_by_title( 'Portfolio' );
$nv_blog      = nuvirahub_get_page_by_title( 'Blog' );
$nv_contact   = nuvirahub_get_page_by_title( 'Contact' );

if ( ! function_exists( 'nv_link' ) ) {
	function nv_link( $page, $slug ) {
		return $page ? get_permalink( $page->ID ) : home_url( '/' . $slug );
	}
}
?>

<footer class="nv-footer">
	<div class="nv-footer-grid">
		<div>
			<div class="nv-footer-brand"><?php echo esc_html( get_bloginfo( 'name' ) ? get_bloginfo( 'name' ) : 'Nuvirahub' ); ?></div>
			<p class="nv-footer-desc">A boutique digital studio crafting modern websites and digital experiences that help brands grow and stand out.</p>
			<div class="nv-social" style="margin-top:20px">
				<a class="nv-social-btn" href="#">&#120143;</a>
				<a class="nv-social-btn" href="#">in</a>
				<a class="nv-social-btn" href="#">f</a>
			</div>
		</div>
		<div>
			<h4>Services</h4>
			<a class="nv-footer-link" href="<?php echo esc_url( nv_link( $nv_services, 'services' ) ); ?>">UI/UX Design</a>
			<a class="nv-footer-link" href="<?php echo esc_url( nv_link( $nv_services, 'services' ) ); ?>">Web Development</a>
			<a class="nv-footer-link" href="<?php echo esc_url( nv_link( $nv_services, 'services' ) ); ?>">E-Commerce</a>
			<a class="nv-footer-link" href="<?php echo esc_url( nv_link( $nv_services, 'services' ) ); ?>">SEO &amp; Growth</a>
		</div>
		<div>
			<h4>Company</h4>
			<a class="nv-footer-link" href="<?php echo esc_url( nv_link( $nv_about, 'about' ) ); ?>">About Us</a>
			<a class="nv-footer-link" href="<?php echo esc_url( nv_link( $nv_portfolio, 'portfolio' ) ); ?>">Portfolio</a>
			<a class="nv-footer-link" href="<?php echo esc_url( nv_link( $nv_blog, 'blog' ) ); ?>">Blog</a>
			<a class="nv-footer-link" href="<?php echo esc_url( nv_link( $nv_contact, 'contact' ) ); ?>">Contact</a>
		</div>
		<div>
			<h4>Connect</h4>
			<a class="nv-footer-link" href="mailto:<?php echo esc_attr( get_option( 'admin_email' ) ); ?>"><?php echo esc_html( get_option( 'admin_email' ) ); ?></a>
			<span class="nv-footer-link">Colombo, Sri Lanka</span>
			<span class="nv-footer-link">Mon&ndash;Fri 9am&ndash;6pm</span>
		</div>
	</div>
	<div class="nv-footer-bottom">
		<span>&copy; <?php echo esc_html( gmdate( 'Y' ) ); ?> <?php echo esc_html( get_bloginfo( 'name' ) ? get_bloginfo( 'name' ) : 'Nuvirahub' ); ?>. All rights reserved.</span>
		<span>Built with &#10022; by Nuvirahub</span>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
