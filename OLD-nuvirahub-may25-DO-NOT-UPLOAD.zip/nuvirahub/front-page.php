<?php
/**
 * Front page (Home) template.
 *
 * @package Nuvirahub
 */

get_header();

$nv_portfolio = nuvirahub_get_page_by_title( 'Portfolio' );
$nv_services  = nuvirahub_get_page_by_title( 'Services' );
$nv_contact   = nuvirahub_get_page_by_title( 'Contact' );
$portfolio_url = $nv_portfolio ? get_permalink( $nv_portfolio->ID ) : home_url( '/portfolio' );
$services_url  = $nv_services ? get_permalink( $nv_services->ID ) : home_url( '/services' );
$contact_url   = $nv_contact ? get_permalink( $nv_contact->ID ) : home_url( '/contact' );
?>

<section class="nv-hero">
	<div class="nv-hero-bg">
		<div class="nv-hero-grid"></div>
		<div class="nv-orb nv-orb1"></div>
		<div class="nv-orb nv-orb2"></div>
		<div class="nv-orb nv-orb3"></div>
	</div>
	<div class="nv-hero-content">
		<div class="nv-badge"><span class="nv-badge-dot"></span>Available for new projects</div>
		<h1>We Build Digital<br><span>Experiences</span> That Matter</h1>
		<p class="nv-hero-sub">Nuvirahub crafts modern, high-performance websites and digital solutions that help brands grow, convert, and inspire.</p>
		<div class="nv-hero-actions">
			<a class="nv-btn-primary" href="<?php echo esc_url( $portfolio_url ); ?>">View Our Work</a>
			<a class="nv-btn-ghost" href="<?php echo esc_url( $services_url ); ?>">Explore Services</a>
		</div>
		<div class="nv-hero-stats">
			<div class="nv-stat"><div class="nv-stat-num">50+</div><div class="nv-stat-label">Projects Delivered</div></div>
			<div class="nv-stat"><div class="nv-stat-num">98%</div><div class="nv-stat-label">Client Satisfaction</div></div>
			<div class="nv-stat"><div class="nv-stat-num">5yr</div><div class="nv-stat-label">Experience</div></div>
			<div class="nv-stat"><div class="nv-stat-num">24h</div><div class="nv-stat-label">Response Time</div></div>
		</div>
	</div>
</section>

<div class="nv-strip">
	<div class="nv-marquee">
		<?php
		$items = array( 'Web Design', 'UI/UX Development', 'Digital Strategy', 'Brand Identity', 'E-Commerce Solutions', 'SEO Optimisation', 'WordPress Experts' );
		// Print twice for seamless loop.
		for ( $i = 0; $i < 2; $i++ ) {
			foreach ( $items as $item ) {
				echo '<span class="nv-marquee-item"><span class="nv-marquee-dot"></span>' . esc_html( $item ) . '</span>';
			}
		}
		?>
	</div>
</div>

<div class="nv-section nv-reveal">
	<div class="nv-tag">What we do</div>
	<h2 class="nv-title">Everything you need to thrive online</h2>
	<p class="nv-sub">From concept to launch &mdash; we handle design, development, and digital growth so you can focus on what matters most.</p>
	<div class="nv-grid-3">
		<div class="nv-glass"><div class="nv-card-icon" style="background:rgba(108,99,255,.15);border-color:rgba(108,99,255,.3)">&#127912;</div><h4 style="font-family:'Syne',sans-serif;font-size:16px;font-weight:600;margin-bottom:8px">UI/UX Design</h4><p style="font-size:13px;color:var(--muted2);line-height:1.7">Glassmorphism, motion design, and user-centered interfaces that delight visitors and drive conversions.</p></div>
		<div class="nv-glass"><div class="nv-card-icon" style="background:rgba(56,189,248,.1);border-color:rgba(56,189,248,.3)">&#9889;</div><h4 style="font-family:'Syne',sans-serif;font-size:16px;font-weight:600;margin-bottom:8px">Web Development</h4><p style="font-size:13px;color:var(--muted2);line-height:1.7">Fast, responsive, and scalable websites built on WordPress and modern frameworks with clean code.</p></div>
		<div class="nv-glass"><div class="nv-card-icon" style="background:rgba(245,158,11,.1);border-color:rgba(245,158,11,.3)">&#128200;</div><h4 style="font-family:'Syne',sans-serif;font-size:16px;font-weight:600;margin-bottom:8px">Growth Strategy</h4><p style="font-size:13px;color:var(--muted2);line-height:1.7">SEO, content strategy, and analytics to get you found, grow your audience, and measure what works.</p></div>
	</div>
</div>

<div class="nv-divider"></div>

<div class="nv-section nv-reveal">
	<div class="nv-tag">How it works</div>
	<h2 class="nv-title">Our proven process</h2>
	<div class="nv-process">
		<div class="nv-step"><div class="nv-step-num">1</div><div class="nv-step-title">Discovery</div><div class="nv-step-desc">We learn your goals, audience, and vision through a deep-dive consultation.</div></div>
		<div class="nv-step"><div class="nv-step-num">2</div><div class="nv-step-title">Strategy</div><div class="nv-step-desc">We map out a clear plan: sitemap, wireframes, and technical specs.</div></div>
		<div class="nv-step"><div class="nv-step-num">3</div><div class="nv-step-title">Design</div><div class="nv-step-desc">Pixel-perfect designs with your brand identity, tested for usability.</div></div>
		<div class="nv-step"><div class="nv-step-num">4</div><div class="nv-step-title">Launch</div><div class="nv-step-desc">We deploy, test, and hand you the keys with full training and support.</div></div>
	</div>
</div>

<div class="nv-divider"></div>

<div class="nv-section nv-reveal">
	<div class="nv-tag">Client feedback</div>
	<h2 class="nv-title">What our clients say</h2>
	<div class="nv-grid-3" style="margin-top:40px">
		<div class="nv-testimonial"><p class="nv-testimonial-text">"Nuvirahub transformed our outdated website into something we're genuinely proud of. The design is stunning and conversions are up 40%."</p><div class="nv-testimonial-author"><div class="nv-testimonial-avatar">SA</div><div><div style="font-size:13px;font-weight:500">Sarah A.</div><div style="font-size:11px;color:var(--muted)">CEO, TechBridge</div></div></div></div>
		<div class="nv-testimonial"><p class="nv-testimonial-text">"Professional, fast, and creative. The team understood our brief perfectly and delivered beyond expectations. Highly recommended!"</p><div class="nv-testimonial-author"><div class="nv-testimonial-avatar" style="background:linear-gradient(135deg,#0ea5e9,#06b6d4)">MK</div><div><div style="font-size:13px;font-weight:500">Marcus K.</div><div style="font-size:11px;color:var(--muted)">Founder, Kreative Co.</div></div></div></div>
		<div class="nv-testimonial"><p class="nv-testimonial-text">"The glassmorphism redesign made us look like a premium brand. Our clients constantly compliment the website. Worth every cent."</p><div class="nv-testimonial-author"><div class="nv-testimonial-avatar" style="background:linear-gradient(135deg,#f59e0b,#ef4444)">PJ</div><div><div style="font-size:13px;font-weight:500">Priya J.</div><div style="font-size:11px;color:var(--muted)">Director, NovaBuild</div></div></div></div>
	</div>
</div>

<div class="nv-section nv-reveal" style="padding-top:0">
	<div class="nv-newsletter">
		<div class="nv-tag" style="margin-bottom:12px">Stay updated</div>
		<h2 class="nv-title" style="font-size:32px;margin-bottom:8px">Get digital insights monthly</h2>
		<p style="font-size:14px;color:var(--muted2)">Design tips, web trends, and Nuvirahub project updates &mdash; no spam, ever.</p>
		<form class="nv-newsletter-form" action="<?php echo esc_url( $contact_url ); ?>" method="get">
			<input type="email" name="subscribe" placeholder="Your email address" required>
			<button class="nv-btn-primary" style="padding:11px 24px" type="submit">Subscribe</button>
		</form>
	</div>
</div>

<?php
get_footer();
